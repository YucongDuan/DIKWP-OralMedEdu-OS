# Roadmap

- v0.2: richer oral medicine module library.
- v0.3: OSCE station builder.
- v0.4: teacher dashboard and student analytics.
- v0.5: residency competency integration.
- v1.0: institutional pilot with audit report.
