# GitHub Release Draft

DIKWP OralMedEdu OS v0.1.0 is released as an offline-first oral medical education management and AI governance system.

It includes curriculum ledger, student path, teacher pack, internship/residency logbook governance, mock exam readiness, AI request guard and standalone demo.
