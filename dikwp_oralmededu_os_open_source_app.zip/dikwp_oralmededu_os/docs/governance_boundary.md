# Governance Boundary

This system is for education governance. It must not be used for clinical diagnosis, treatment, exam cheating, credential capture, punitive student ranking, or official exam impersonation.
