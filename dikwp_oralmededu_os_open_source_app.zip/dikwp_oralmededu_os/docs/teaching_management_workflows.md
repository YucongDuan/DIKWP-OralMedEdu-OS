# Teaching Management Workflows

The teaching office can use this system for:

- Course schedule planning.
- Rubric generation.
- Student support queue.
- Teacher workload visibility.
- Exam item provenance management.
- OSCE station governance.
- Rotation logbook integrity.
- AI usage policy enforcement.

Daily administrative tasks are routed into `automate_draft_only` or `human_admin_review_required`.
