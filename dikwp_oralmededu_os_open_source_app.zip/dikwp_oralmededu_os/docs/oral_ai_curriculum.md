# Oral Medicine AI Teaching System Construction

Recommended longitudinal AI curriculum:

1. AI literacy and evidence ledger.
2. Patient privacy and data minimization.
3. AI hallucination and source verification.
4. Oral anatomy concept mapping.
5. Caries and periodontal risk communication.
6. Radiology and CBCT evidence boundaries.
7. Digital dentistry workflow literacy.
8. Clinical reasoning with teacher review.
9. AI-assisted feedback and portfolio learning.
10. Ethical and legal responsibility.

Students may use AI for explanation, concept mapping, retrieval practice, reflective writing, and evidence-led case preparation. AI cannot diagnose, prescribe, recommend patient-specific treatment, or replace supervisor review.
