# 90-Day Implementation Plan

## Days 1-15
Collect curriculum modules, existing rubrics, exam policies and rotation logbooks.

## Days 16-30
Build AI use policy, student learning path templates and teacher lesson pack templates.

## Days 31-60
Pilot in two oral medicine courses and one OSCE module.

## Days 61-90
Extend to internship/residency logbooks, mock exam platform and teaching office workflows.

Success metrics: fewer administrative delays, more traceable rubrics, safer AI usage, stronger exam item provenance, better student remediation visibility.
