# AI Governance Boundary

Allowed:
- Concept explanation.
- Dry-lab teaching.
- Mock cases.
- Rubric drafts.
- Learning path suggestions.
- Evidence-led review.

Review required:
- Clinical cases.
- Radiographs and CBCT.
- OSCE stations.
- Residency evaluations.
- Formal exam management.

Blocked:
- Diagnosis.
- Prescribing.
- Treatment decisions.
- Leaked exam questions.
- Cheating assistance.
- Credential capture.
- Official exam automation.
