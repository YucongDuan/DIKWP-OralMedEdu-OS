# Architecture

The system uses an offline-first architecture:

1. Case intake JSON.
2. DIKWP education ledger.
3. Curriculum readiness scoring.
4. Student learning path generation.
5. Teacher teaching pack generation.
6. Internship/residency logbook governance.
7. Exam blueprint and item provenance governance.
8. AI request guard.
9. Static boundary audit.
10. Optional HTML and Streamlit UI.

No network, no credential capture, no official exam automation, no clinical decision automation.
