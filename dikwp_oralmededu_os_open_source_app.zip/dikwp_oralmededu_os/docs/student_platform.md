# Student Learning Platform

The student platform outputs:

- Personal learning path.
- Concept repair list.
- Retrieval practice plan.
- Misconception map.
- AI use boundary.
- Exam readiness matrix.
- Rotation competency checklist.

It must not rank students punitively or make high-stakes decisions automatically.
