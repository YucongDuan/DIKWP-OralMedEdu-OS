# Teacher Teaching Platform

The teacher platform supports:

- Lesson plan drafts.
- Case discussion outlines.
- Rubric suggestions.
- Feedback summary drafts.
- AI output audit templates.
- Student misconception analysis.
- OSCE station drafting.

The teacher retains final authority over clinical content, grading and student progression.
