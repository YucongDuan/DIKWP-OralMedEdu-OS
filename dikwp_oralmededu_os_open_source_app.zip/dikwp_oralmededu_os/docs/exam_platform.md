# National Licensing Simulation and Authorized Exam Governance

The system supports mock exams and institutional authorized exams. It does not impersonate the National Medical Examination Center, does not use leaked items, and does not automate official exam submission.

Core modules:

- Blueprint alignment.
- Faculty-created item bank.
- Item provenance ledger.
- Exam committee review.
- OSCE station governance.
- Accessibility accommodation.
- Integrity audit.
- Appeal channel.

Formal exam modules require institutional authorization and human exam office governance.
