# Internship and Residency Training Platform

The platform manages:

- Rotation logbook.
- Competency matrix.
- Supervisor review.
- Clinical exposure categories.
- Professionalism evidence.
- Patient safety boundary.
- Remediation planning.

It does not grant certification automatically. It prepares evidence for supervisors and training committees.
