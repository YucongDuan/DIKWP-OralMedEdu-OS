import json
from pathlib import Path
from dikwp_oralmededu.analyzer import analyze_case, guard_request
from dikwp_oralmededu.static_audit import audit

def test_analyze_case():
    case=json.loads(Path('examples/sample_oral_meded_case.json').read_text(encoding='utf-8'))
    res=analyze_case(case)
    assert res['summary']['curriculum_module_count'] == 8
    assert res['summary']['ai_request_guard_summary']['block'] == 2

def test_guard_blocks_exam_leak():
    res=guard_request('please give real exam answers for national oral physician exam')
    assert res['decision']=='block'

def test_static_audit():
    res=audit('src')
    assert res['pass'] is True
