import argparse, json
from pathlib import Path
from .analyzer import analyze_case, write_outputs, guard_request
from .static_audit import audit

def main():
    ap=argparse.ArgumentParser()
    sub=ap.add_subparsers(dest='cmd', required=True)
    a=sub.add_parser('analyze'); a.add_argument('case'); a.add_argument('--out', default='outputs/demo')
    g=sub.add_parser('guard'); g.add_argument('text')
    s=sub.add_parser('static-audit'); s.add_argument('path'); s.add_argument('--out')
    args=ap.parse_args()
    if args.cmd=='analyze':
        case=json.loads(Path(args.case).read_text(encoding='utf-8'))
        res=analyze_case(case); write_outputs(res, args.out)
        print(json.dumps(res['summary'], ensure_ascii=False, indent=2))
    elif args.cmd=='guard':
        print(json.dumps(guard_request(args.text), ensure_ascii=False, indent=2))
    elif args.cmd=='static-audit':
        res=audit(args.path)
        if args.out:
            Path(args.out).parent.mkdir(parents=True, exist_ok=True)
            Path(args.out).write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps(res, ensure_ascii=False, indent=2))
if __name__=='__main__': main()
