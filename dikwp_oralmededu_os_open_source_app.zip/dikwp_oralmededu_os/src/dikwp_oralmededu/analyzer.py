import json, re, csv
from pathlib import Path
from typing import Dict, Any, List

BLOCK_TERMS = [
    "leaked exam", "real exam answers", "替考", "泄题", "真题答案", "作弊", "代考", "绕过监考",
    "diagnose patient", "prescribe", "treatment plan for a patient", "clinical decision", "诊断患者", "开药", "治疗方案",
    "capture password", "session cookie", "api key", "credentials", "身份证号采集", "人脸作弊"
]
REVIEW_TERMS = [
    "患者", "临床病例", "真实病历", "影像", "CBCT", "处方", "手术", "麻醉", "知情同意", "正式考试", "国家考试",
    "OSCE", "住培", "规培", "实习"
]

TOPIC_TAGS = {
    "oral_anatomy": ["解剖", "anatomy", "牙体", "颌面"],
    "oral_pathology": ["病理", "pathology", "病变", "癌"],
    "periodontology": ["牙周", "periodontal", "periodontitis"],
    "endodontics": ["牙体牙髓", "endodontics", "root canal", "根管"],
    "prosthodontics": ["修复", "prosthodontics", "义齿", "冠"],
    "orthodontics": ["正畸", "orthodontics", "错合"],
    "oral_surgery": ["口腔颌面外科", "surgery", "拔牙", "implant", "种植"],
    "radiology": ["影像", "radiology", "CBCT", "X线"],
    "preventive": ["预防", "public health", "fluoride", "龋病风险"],
    "ethics_ai": ["AI", "伦理", "隐私", "数据", "算法"]
}

def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))

def classify_topic(text: str) -> List[str]:
    found = []
    low = text.lower()
    for tag, keys in TOPIC_TAGS.items():
        if any(k.lower() in low for k in keys):
            found.append(tag)
    return found or ["general_stomatology"]

def guard_request(text: str) -> Dict[str, Any]:
    low = text.lower()
    reasons = []
    for term in BLOCK_TERMS:
        if term.lower() in low:
            reasons.append(f"Blocked term or intent: {term}")
    if reasons:
        return {"decision": "block", "risk_score": 1.0, "reasons": reasons}
    review = []
    for term in REVIEW_TERMS:
        if term.lower() in low:
            review.append(f"Instructor or authorized exam review trigger: {term}")
    if review:
        return {"decision": "instructor_or_exam_office_review_required", "risk_score": 0.64, "reasons": review}
    return {"decision": "allow_education_dry_lab", "risk_score": 0.15, "reasons": ["Conceptual or administrative education request."]}

def module_score(module: Dict[str, Any]) -> Dict[str, Any]:
    outcomes = module.get("outcomes", [])
    ai_use = module.get("ai_use", "none")
    assessment = module.get("assessment", [])
    clinical = module.get("clinical_sensitivity", 0.0)
    evidence = module.get("evidence_strength", 0.5)
    ai_bonus = {"none":0.0,"assistive":0.1,"guided":0.18,"simulation":0.22,"assessment_support":0.16}.get(ai_use,0.05)
    readiness = clamp(0.25 + 0.08*len(outcomes) + 0.04*len(assessment) + ai_bonus + 0.25*evidence - 0.18*clinical)
    review_required = clinical >= 0.45 or ai_use in ["assessment_support", "simulation"]
    return {"readiness": round(readiness,3), "review_required": review_required}

def analyze_case(case: Dict[str, Any]) -> Dict[str, Any]:
    modules = case.get("curriculum_modules", [])
    students = case.get("students", [])
    teachers = case.get("teachers", [])
    rotations = case.get("rotations", [])
    exam_items = case.get("exam_items", [])
    ai_requests = case.get("ai_requests", [])
    admin_tasks = case.get("admin_tasks", [])

    mod_rows = []
    for m in modules:
        sc = module_score(m)
        mod_rows.append({**m, **sc, "topics": ";".join(classify_topic(m.get("title","")+" "+m.get("description","")))})
    mean_ready = sum(r["readiness"] for r in mod_rows)/len(mod_rows) if mod_rows else 0

    student_paths = []
    for s in students:
        deficits = s.get("deficits", [])
        supports = s.get("support_needs", [])
        risk = clamp(0.2 + 0.12*len(deficits) + 0.08*len(supports) - 0.06*len(s.get("strengths", [])))
        path = []
        for d in deficits:
            path.append(f"Repair {d} with concept map, retrieval practice, and teacher-reviewed cases.")
        student_paths.append({"student_id": s["student_id"], "support_risk": round(risk,3), "learning_path": path})

    teacher_pack = []
    for t in teachers:
        load = clamp(0.2 + 0.1*len(t.get("courses",[])) + 0.12*t.get("admin_load",0) - 0.1*t.get("ai_readiness",0))
        teacher_pack.append({"teacher_id": t["teacher_id"], "workload_pressure": round(load,3), "recommendation": "Use AI for draft rubrics and feedback summaries; keep clinical judgment and grading finalization with teacher."})

    rotation_rows = []
    for r in rotations:
        coverage = len(r.get("competencies", [])) / 8.0
        supervision = r.get("supervision_level", 0.5)
        readiness = clamp(0.25 + 0.45*coverage + 0.3*supervision)
        rotation_rows.append({"rotation_id": r["rotation_id"], "department": r.get("department"), "readiness": round(readiness,3), "logbook_required": True})

    exam_governance = []
    for item in exam_items:
        text = item.get("stem", "") + " " + " ".join(item.get("tags", []))
        topics = classify_topic(text)
        risk = 0.2
        reasons=[]
        if item.get("source") == "leaked" or item.get("official_real_item", False):
            risk = 1.0; reasons.append("Real or leaked official exam item is not allowed.")
            decision="block"
        elif item.get("source") == "faculty_created" and item.get("reviewed", False):
            risk = 0.2; decision="usable_for_mock_exam"
        else:
            risk = 0.55; decision="exam_committee_review_required"; reasons.append("Source/review status incomplete.")
        exam_governance.append({"item_id": item["item_id"], "decision": decision, "risk_score": risk, "topics": ";".join(topics), "reasons": ";".join(reasons)})

    guards = [ {"request_id": req.get("request_id"), **guard_request(req.get("text",""))} for req in ai_requests]
    guard_summary = {}
    for g in guards:
        guard_summary[g["decision"]] = guard_summary.get(g["decision"], 0) + 1

    admin_queue = []
    for task in admin_tasks:
        urgency = task.get("urgency", 0.5)
        data_sens = task.get("data_sensitivity", 0.4)
        auto = task.get("automation_candidate", 0.5)
        risk = clamp(0.25*urgency + 0.45*data_sens + 0.3*(1-auto))
        decision = "automate_draft_only" if risk < 0.45 else "human_admin_review_required"
        admin_queue.append({"task_id": task["task_id"], "decision": decision, "risk_score": round(risk,3), "owner": task.get("owner", "teaching_office")})

    ledger = []
    for r in mod_rows:
        ledger.append({
            "object_id": r.get("module_id"),
            "D": {"title": r.get("title"), "explicit_materials": r.get("materials", [])},
            "I": {"topics": r.get("topics"), "clinical_sensitivity": r.get("clinical_sensitivity")},
            "K": {"outcomes": r.get("outcomes", []), "assessment": r.get("assessment", [])},
            "W": {"patient_safety": "teacher review for clinical reasoning", "exam_integrity": "no leaked item use"},
            "P": {"goal": "support oral medical education under AI governance", "feedback": "student progress and teacher review"},
            "R": {"readiness": r.get("readiness"), "review_required": r.get("review_required")}
        })

    overall = {
        "system": "DIKWP OralMedEdu OS",
        "version": "0.1.0",
        "case_id": case.get("case_id"),
        "curriculum_module_count": len(modules),
        "student_count": len(students),
        "teacher_count": len(teachers),
        "rotation_count": len(rotations),
        "exam_item_count": len(exam_items),
        "mean_curriculum_ai_readiness": round(mean_ready,3),
        "ai_request_guard_summary": guard_summary,
        "boundary": "education management and simulation only; no diagnosis, treatment, official exam impersonation, exam leakage, or credential capture"
    }
    return {"summary": overall, "modules": mod_rows, "students": student_paths, "teachers": teacher_pack, "rotations": rotation_rows, "exam_governance": exam_governance, "ai_guards": guards, "admin_queue": admin_queue, "ledger": ledger}

def write_outputs(result: Dict[str, Any], out: str):
    outp = Path(out); outp.mkdir(parents=True, exist_ok=True)
    (outp/"oralmededu_report.json").write_text(json.dumps(result["summary"], ensure_ascii=False, indent=2), encoding="utf-8")
    (outp/"dikwp_education_ledger.json").write_text(json.dumps(result["ledger"], ensure_ascii=False, indent=2), encoding="utf-8")
    (outp/"student_learning_paths.json").write_text(json.dumps(result["students"], ensure_ascii=False, indent=2), encoding="utf-8")
    (outp/"teacher_platform_pack.json").write_text(json.dumps(result["teachers"], ensure_ascii=False, indent=2), encoding="utf-8")
    (outp/"rotation_logbook.json").write_text(json.dumps(result["rotations"], ensure_ascii=False, indent=2), encoding="utf-8")
    (outp/"exam_blueprint_and_governance.json").write_text(json.dumps(result["exam_governance"], ensure_ascii=False, indent=2), encoding="utf-8")
    (outp/"ai_request_guard_report.json").write_text(json.dumps(result["ai_guards"], ensure_ascii=False, indent=2), encoding="utf-8")
    # CSVs
    def write_csv(path, rows):
        if not rows: return
        keys = list(rows[0].keys())
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=keys); w.writeheader(); w.writerows(rows)
    write_csv(outp/"curriculum_module_matrix.csv", result["modules"])
    write_csv(outp/"admin_task_queue.csv", result["admin_queue"])
    write_csv(outp/"rotation_competency_matrix.csv", result["rotations"])
    write_csv(outp/"exam_governance_matrix.csv", result["exam_governance"])
    # Markdown docs
    md = ["# Student Learning Platform Pack", ""]
    for s in result["students"]:
        md.append(f"## {s['student_id']}")
        md.append(f"Support risk: {s['support_risk']}")
        for p in s["learning_path"]: md.append(f"- {p}")
    (outp/"student_learning_platform_pack.md").write_text("\n".join(md), encoding="utf-8")
    teacher = ["# Teacher Teaching Platform Pack", "", "Use AI for draft generation, retrieval practice, rubric suggestions, and feedback summaries. Clinical judgment and summative grading remain teacher-owned."]
    for t in result["teachers"]:
        teacher.append(f"\n## {t['teacher_id']}\n- Workload pressure: {t['workload_pressure']}\n- {t['recommendation']}")
    (outp/"teacher_teaching_platform_pack.md").write_text("\n".join(teacher), encoding="utf-8")
    policy = """# Formal Exam Governance Policy\n\nThis system supports mock exams and authorized institutional exams only.\n\nIt does not impersonate the National Medical Examination Center, does not use leaked items, does not capture credentials, and does not automate official exam submission.\n\nFormal examination modules require: item provenance, exam committee review, candidate eligibility verification, accessibility accommodation, proctor integrity, appeal channel, and audit log.\n"""
    (outp/"formal_exam_governance_policy.md").write_text(policy, encoding="utf-8")
    return result
