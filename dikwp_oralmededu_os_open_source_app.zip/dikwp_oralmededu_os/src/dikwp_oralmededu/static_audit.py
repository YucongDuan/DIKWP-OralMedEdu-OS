import ast, os, json
from pathlib import Path

FORBIDDEN_IMPORTS = {"requests", "urllib", "httpx", "selenium", "playwright", "subprocess", "socket"}
FORBIDDEN_CALLS = {"eval", "exec", "compile", "__import__"}
FORBIDDEN_TEXT = []  # text redline terms are handled by the request guard, not by source static audit

def audit(path: str):
    findings=[]
    for root, _, files in os.walk(path):
        for fn in files:
            if not fn.endswith('.py'): continue
            p=Path(root)/fn
            txt=p.read_text(encoding='utf-8')
            for term in FORBIDDEN_TEXT:
                if term in txt.lower(): findings.append({"file":str(p), "type":"forbidden_text", "term":term})
            try:
                tree=ast.parse(txt)
            except Exception as e:
                findings.append({"file":str(p), "type":"parse_error", "error":str(e)}); continue
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        if alias.name.split('.')[0] in FORBIDDEN_IMPORTS:
                            findings.append({"file":str(p), "type":"forbidden_import", "name":alias.name})
                if isinstance(node, ast.ImportFrom):
                    mod=(node.module or '').split('.')[0]
                    if mod in FORBIDDEN_IMPORTS:
                        findings.append({"file":str(p), "type":"forbidden_import", "name":node.module})
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in FORBIDDEN_CALLS:
                    findings.append({"file":str(p), "type":"forbidden_call", "name":node.func.id})
    return {"pass": len(findings)==0, "finding_count": len(findings), "findings": findings, "policy": "No network imports, browser automation, subprocess, dynamic execution, credential capture, exam cheating, or clinical decision automation in offline core."}
