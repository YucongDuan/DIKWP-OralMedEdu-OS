try:
    import streamlit as st
    import json
    from .analyzer import analyze_case
    st.title('DIKWP OralMedEdu OS')
    uploaded = st.file_uploader('Upload oral medical education case JSON')
    if uploaded:
        case=json.loads(uploaded.read().decode('utf-8'))
        res=analyze_case(case)
        st.json(res['summary'])
        st.dataframe(res['modules'])
        st.dataframe(res['exam_governance'])
    else:
        st.info('Upload a case JSON or use CLI demo.')
except Exception:
    pass
