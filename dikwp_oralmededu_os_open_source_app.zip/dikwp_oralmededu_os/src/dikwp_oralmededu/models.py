from dataclasses import dataclass, field
from typing import Any, Dict, List

@dataclass
class DIKWPRecord:
    D: Dict[str, Any]
    I: Dict[str, Any]
    K: Dict[str, Any]
    W: Dict[str, Any]
    P: Dict[str, Any]
    R: Dict[str, Any]

@dataclass
class Decision:
    decision: str
    score: float
    reasons: List[str] = field(default_factory=list)
