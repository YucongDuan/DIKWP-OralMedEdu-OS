# Formal Exam Governance Policy

This system supports mock exams and authorized institutional exams only.

It does not impersonate the National Medical Examination Center, does not use leaked items, does not capture credentials, and does not automate official exam submission.

Formal examination modules require: item provenance, exam committee review, candidate eligibility verification, accessibility accommodation, proctor integrity, appeal channel, and audit log.
