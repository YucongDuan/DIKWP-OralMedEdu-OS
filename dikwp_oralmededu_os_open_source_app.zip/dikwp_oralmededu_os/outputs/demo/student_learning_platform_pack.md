# Student Learning Platform Pack

## S001
Support risk: 0.48
- Repair periodontal evidence with concept map, retrieval practice, and teacher-reviewed cases.
- Repair AI hallucination detection with concept map, retrieval practice, and teacher-reviewed cases.
## S002
Support risk: 0.46
- Repair endodontic sequencing with concept map, retrieval practice, and teacher-reviewed cases.
- Repair exam time management with concept map, retrieval practice, and teacher-reviewed cases.