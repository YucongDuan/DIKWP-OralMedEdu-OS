# Teacher Teaching Platform Pack

Use AI for draft generation, retrieval practice, rubric suggestions, and feedback summaries. Clinical judgment and summative grading remain teacher-owned.

## T001
- Workload pressure: 0.424
- Use AI for draft rubrics and feedback summaries; keep clinical judgment and grading finalization with teacher.

## T002
- Workload pressure: 0.468
- Use AI for draft rubrics and feedback summaries; keep clinical judgment and grading finalization with teacher.